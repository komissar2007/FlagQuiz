/** Automatically generated file. DO NOT MODIFY */
package com.aman.flagquizgame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}